<?php
include 'header.php';
?>
<div class="main" id="main">
  <?php
  echo 'Welcome Admin !';
  ?>
</div>
<?php
include 'footer.php';
?>