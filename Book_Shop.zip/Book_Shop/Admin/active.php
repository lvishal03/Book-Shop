<?php
// if(isset($_POST['catid'])){
//     $catid = $_POST['catid'];

//     $sql = "SELECT * FROM `add_book` WHERE id='$catid'";
//     $result = $conn->query($sql);
//     $data = mysqli_fetch_assoc($result);
//     $status = $data['status'];

    // Toggle the status
    // if($status == '0'){
    //     $status = '1';
    // }else{
    //     $status = '0';
    // }

    // $update = "UPDATE `add_book` SET `b_status`='$status' WHERE id='$catid'";
    // $up_result = $conn->query($update);
    
    // if($up_result){
        // echo $status; // Return the updated status
    // } else {
        // echo 'error'; // You can use this to debug if needed
//     }
// }



?>