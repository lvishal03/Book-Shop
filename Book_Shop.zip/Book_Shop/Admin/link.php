<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,200;1,300;1,500;1,700;1,900&amp;family=Rubik:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300;1,500;1,700;1,900&amp;family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,200;1,300;1,500;1,700;1,900&amp;family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,200;1,300;1,500;1,700;1,900&amp;family=Rubik:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300;1,500;1,700;1,900&amp;family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,200;1,300;1,500;1,700;1,900&amp;family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://safecart.bytesed.com/assets/css/line-awesome.min.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css">




<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="image/download.jfif" rel="icon">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="cs.css">
<link rel="stylesheet" href="https://safecart.bytesed.com/assets/css/bootstrap5.min.css">

<link rel="stylesheet" href="https://safecart.bytesed.com/assets/css/animate.css">

<link rel="stylesheet" href="https://safecart.bytesed.com/assets/css/slick.css">

<link rel="stylesheet" href="https://safecart.bytesed.com/assets/css/line-awesome.min.css">

<link rel="stylesheet" href="https://safecart.bytesed.com/assets/css/plugins.css">

<link rel="stylesheet" href="https://safecart.bytesed.com/assets/css/style.css">
<link rel="stylesheet" href="https://safecart.bytesed.com/assets/common/css/toastr.css">
<link rel="stylesheet" href="https://safecart.bytesed.com/assets/frontend/css/dynamic-style.css">