<?php 
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cart</title>
</head>
<body>
<div class="container cont">
  <img src="../image/h2_hero2.jpg.webp" alt="Snow" class="dd">
  <div class="centered">Cart</div>
</div>
<div class="container mt-4">
        <div class="row">
            <div class="col-md-3 col-12">
                <center><b>Image</b></center><br>
                <img src="../image/hs4.jfif" alt="" style="width: 100%; height:100%;">
            </div>
            <div class="col-md-3 col-6">
                <center><b>Book Name</b><br>
                <span class="mt-5">J.R Jain</span>
            </center>
            </div>
            <div class="col-md-3 col-6 mt-2 mt-md-0">
                <center>
                <b>Quantity</b><br>
                <span class="mt-5">4</span>
                </center>
            </div>
            <div class="col-md-3 col-6 mt-2 mt-md-0">
                <center>
                <b>Price</b><br>
                <span class="mt-5">$1500</span>
                </center>
            </div>
        </div>
    </div>

</body>
</html>