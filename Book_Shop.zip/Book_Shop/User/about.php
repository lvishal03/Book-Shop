    <?php
    include 'header.php';
    ?>

    
<div class="maini" id="maini">
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>About</title>
    </head>

     
    

    <body>
    <div class="container cont">
        <img src="../image/h2_hero2.jpg.webp" alt="Snow">
        <div class="centered">About</div>
    </div>



    <div class="div">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12 ms-5 mt-3">
                    <h3>Our Story</h3>
                    <p class="mt-4">Beryl Cook is one of Britain’s most talented and amusing artists .Beryl’s pictures feature women of all shapes and sizes enjoying <br> themselves .Born between the two world wars, Beryl Cook eventually left Kendrick School in Reading at the age of 15, where she went to <br> secretarial school and then into an insurance office. After moving to London and then Hampton, she eventually married her next door <br> neighbour from Reading, John Cook. He was an officer in the Merchant Navy and after he left the sea in 1956, they bought a pub for a year <br> before John took a job in Southern Rhodesia with a motor company. Beryl bought their young son a box of watercolours, and when <br> showing him how to use it, she decided that she herself quite enjoyed painting. John subsequently bought her a child’s painting set for her <br> birthday and it was with this that she produced her first significant work, a half-length portrait of a dark-skinned lady with a vacant <br> expression and large drooping breasts. It was aptly named ‘Hangover’ by Beryl’s husband and</p>

                   <p class="mt-4"> It is often frustrating to attempt to plan meals that are designed for one. Despite this fact, we are seeing more and more recipe books and <br> Internet websites that are dedicated to the act of cooking for one. Divorce and the death of spouses or grown children leaving for college <br> are all reasons that someone accustomed to cooking for more than one would suddenly need to learn how to adjust all the cooking <br> practices utilized before into a streamlined plan of cooking that is more efficient for one person creating less.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="div">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12 ms-5 mt-3 mb-5">
                    <h3>Our Goal</h3>
                    <p class="mt-4">Beryl Cook is one of Britain’s most talented and amusing artists .Beryl’s pictures feature women of all shapes and sizes enjoying <br> themselves .Born between the two world wars, Beryl Cook eventually left Kendrick School in Reading at the age of 15, where she went to <br> secretarial school and then into an insurance office. After moving to London and then Hampton, she eventually married her next door <br> neighbour from Reading, John Cook. He was an officer in the Merchant Navy and after he left the sea in 1956, they bought a pub for a year <br> before John took a job in Southern Rhodesia with a motor company. Beryl bought their young son a box of watercolours, and when <br> showing him how to use it, she decided that she herself quite enjoyed painting. John subsequently bought her a child’s painting set for her <br> birthday and it was with this that she produced her first significant work, a half-length portrait of a dark-skinned lady with a vacant <br> expression and large drooping breasts. It was aptly named ‘Hangover’ by Beryl’s husband and</p>

                   <p class="mt-4"> It is often frustrating to attempt to plan meals that are designed for one. Despite this fact, we are seeing more and more recipe books and <br> Internet websites that are dedicated to the act of cooking for one. Divorce and the death of spouses or grown children leaving for college <br> are all reasons that someone accustomed to cooking for more than one would suddenly need to learn how to adjust all the cooking <br> practices utilized before into a streamlined plan of cooking that is more efficient for one person creating less.</p>
                </div>
            </div>
        </div>
    </div>

    </body>

</html>
<?php
include 'footer1.php';
?>