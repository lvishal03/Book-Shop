<?php
 include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Order</title>
</head>
<body>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui excepturi reprehenderit repellat debitis perspiciatis? Natus nulla soluta eaque libero exercitationem. Aspernatur mollitia eligendi cupiditate obcaecati numquam, suscipit cum minus assumenda deleniti, iure facere corrupti officiis, in quas placeat modi dolorum soluta vitae perspiciatis ullam exercitationem quidem earum ipsum. Nesciunt consequuntur officiis at corrupti tenetur vitae eos quae atque numquam asperiores vero, facere illum deleniti expedita quo eligendi neque ducimus assumenda culpa earum rerum rem, enim unde. Delectus explicabo ullam autem mollitia enim consectetur nostrum corporis, pariatur quia ex molestias non accusantium deleniti ab quos quo numquam veritatis neque temporibus, praesentium molestiae necessitatibus. Quidem, nobis? Veritatis perspiciatis quia unde quibusdam fuga eveniet, temporibus saepe necessitatibus odio optio harum ut odit, earum sunt quidem corporis nemo quam omnis quo id consectetur. Minus porro esse suscipit incidunt, sapiente odit. Voluptatibus, qui repudiandae, expedita optio et, omnis quidem inventore tempora repellat ad vitae exercitationem quod odit. Assumenda mollitia harum unde aliquid. Nemo eligendi, molestiae, non inventore facilis cumque possimus ad omnis nesciunt laboriosam quidem dolor vero, fugiat voluptatum totam exercitationem. Nihil dolor magni alias, quod pariatur maxime ratione at sed dignissimos corrupti, laboriosam provident autem nemo. Debitis adipisci officiis ea, magni molestias illo quisquam?    
    </p>
</body>
</html>
<?php
include 'footer1.php'
?>